import { useMemo, useRef } from "react";
import { useFrame } from "@react-three/fiber";
import { Float, Plane } from "@react-three/drei";
import * as THREE from "three";
import InteractiveCard from "./InteractiveCard.jsx";
import { useScrollProgressRef } from "./useScrollProgress.js";

const BUTTER_100 = "#fff7d7";
const BUTTER_50 = "#fffdf3";
const BLUE_600 = "#5c7c93";
const BLUE_300 = "#b9cbd4";

const prefersReducedMotion =
  typeof window !== "undefined" &&
  window.matchMedia("(prefers-reduced-motion: reduce)").matches;

function Tabletop() {
  return (
    <mesh position={[0, -1.2, -5]} rotation={[-Math.PI * 0.15, 0, 0]}>
      <planeGeometry args={[8, 6]} />
      <meshStandardMaterial color={BUTTER_100} roughness={0.8} metalness={0.1} />
    </mesh>
  );
}

function Receipt({ scrollProgress }) {
  const receiptRef = useRef();
  
  useFrame(() => {
    if (!receiptRef.current) return;
    receiptRef.current.rotation.x = -0.2 + scrollProgress.current * 0.15;
    receiptRef.current.position.y = -0.3 + scrollProgress.current * 0.8;
  });

  return (
    <group ref={receiptRef} position={[0, -0.3, -3.5]}>
      {/* Receipt paper */}
      <mesh position={[0, 0, 0]}>
        <planeGeometry args={[1.4, 2.4]} />
        <meshStandardMaterial color={BUTTER_50} roughness={0.95} side={THREE.DoubleSide} />
      </mesh>
      
      {/* Line items strips */}
      <mesh position={[0, 0.7, 0.01]}>
        <planeGeometry args={[1.2, 0.15]} />
        <meshStandardMaterial color={BLUE_300} roughness={0.7} />
      </mesh>
      <mesh position={[0, 0.45, 0.01]}>
        <planeGeometry args={[1.2, 0.15]} />
        <meshStandardMaterial color={BLUE_600} roughness={0.7} />
      </mesh>
      <mesh position={[0, 0.2, 0.01]}>
        <planeGeometry args={[1.2, 0.15]} />
        <meshStandardMaterial color={BLUE_300} roughness={0.7} />
      </mesh>
    </group>
  );
}

function CoffeeCup() {
  return (
    <group position={[-2.2, -0.8, -4]}>
      <mesh>
        <cylinderGeometry args={[0.3, 0.35, 0.7, 16]} />
        <meshStandardMaterial color="#d4a574" roughness={0.6} />
      </mesh>
      <mesh position={[0.4, 0.1, 0]}>
        <torusGeometry args={[0.2, 0.08, 8, 16]} />
        <meshStandardMaterial color="#d4a574" roughness={0.6} />
      </mesh>
    </group>
  );
}

function Plate() {
  return (
    <mesh position={[2, -0.95, -4.5]} rotation={[0, 0.3, 0]}>
      <cylinderGeometry args={[0.8, 0.8, 0.1, 32]} />
      <meshStandardMaterial color={BUTTER_50} roughness={0.7} metalness={0.15} />
    </mesh>
  );
}

function Coin() {
  return (
    <mesh position={[-1, -0.9, -3.8]} rotation={[Math.PI * 0.3, 0.4, 0]}>
      <cylinderGeometry args={[0.25, 0.25, 0.04, 32]} />
      <meshStandardMaterial color="#d4af37" roughness={0.4} metalness={0.8} />
    </mesh>
  );
}

function ReceiptClip() {
  return (
    <mesh position={[0.6, 1, -3.4]} rotation={[0.1, 0, 0.3]}>
      <boxGeometry args={[0.12, 0.6, 0.08]} />
      <meshStandardMaterial color="#6b7f8f" roughness={0.5} metalness={0.7} />
    </mesh>
  );
}

export default function CreateSceneContent() {
  const groupRef = useRef();
  const scrollProgress = useScrollProgressRef();

  useFrame((_, delta) => {
    if (!groupRef.current) return;
    const targetZ = -5 + scrollProgress.current * 0.5;
    groupRef.current.position.z = THREE.MathUtils.lerp(
      groupRef.current.position.z,
      targetZ,
      Math.min(delta * 2, 1),
    );
  });

  return (
    <group ref={groupRef}>
      <Tabletop />
      
      <Float speed={0.5} rotationIntensity={0.08} floatIntensity={0.2}>
        <Receipt scrollProgress={scrollProgress} />
      </Float>

      <Float speed={0.4} rotationIntensity={0.12} floatIntensity={0.15} floatingRange={[-0.1, 0.1]}>
        <CoffeeCup />
      </Float>

      <Float speed={0.35} rotationIntensity={0.05} floatIntensity={0.1}>
        <Plate />
      </Float>

      <Float speed={0.6} rotationIntensity={0.2} floatIntensity={0.25} floatingRange={[-0.15, 0.15]}>
        <Coin />
      </Float>

      <Float speed={0.45} rotationIntensity={0.1} floatIntensity={0.12}>
        <ReceiptClip />
      </Float>

      {/* Soft shadows */}
      <mesh position={[0, -1.18, -4]}>
        <planeGeometry args={[6, 4]} />
        <meshBasicMaterial color="#000000" transparent opacity={0.15} />
      </mesh>
    </group>
  );
}